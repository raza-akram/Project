# Implementation-of-Unicasting-And-Broadcasting-using-Python
Broadcasting And Unicasting the Mesage using Python as well as GUI Based
First Run the Server File or if we want the GUI based then Run the GSERVER FILE.
then connect the CLient to that Server by using the ipaddress of remote machine
